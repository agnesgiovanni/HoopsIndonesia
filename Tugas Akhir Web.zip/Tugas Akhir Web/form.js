
function startWithCapitalLetter(word){
    return word.charCodeAt(0)>=65 && word.charCodeAt(0)<=90;
}
var cardvisa= document.querySelector('#visacard1');
var cardmaster= document.querySelector('#mastercard1');
function countprice()
{
    var selected = document.getElementById("chosenproduct").value;
    alert("Total Price : " + selected);
    
}
var cardcheck = 0;
function checkradio()
{
    var cardtype1 = document.querySelector('.visacard');
    var cardtype2 = document.querySelector('.mastercard');
    if(cardvisa.checked == true)
    {
        cardtype1.style.display = "block";
        cardtype2.style.display = "none";
        cardcheck = 1;
    } else if(cardmaster.checked == true)
    {
        cardtype2.style.display = "block";
        cardtype1.style.display = "none";
        cardcheck = 2;
    }
    
}
var inputtxt = document.getElementById('cardnum');
function visacardnumber()
{
    var cardno = /^(?:4[0-9]{12}(?:[0-9]{3})?)$/;
    console.log(inputtxt);
    if(inputtxt.value.match(cardno))
    {
        return true;
    }
    else
    {
        alert("Not a valid Visa credit card number!");
        return false;
    }
}
function mastercardnumber()
{
    var cardno = /^(?:5[1-5][0-9]{14})$/;
    if(inputtxt.value.match(cardno))
    {
        return true;
    }
      else
    {
        alert("Not a valid Mastercard number!");
        return false;
    }
}
function checkVali(){
    var all = 0, i = 0;
    var name = document.forms['order']['nama'].value
    var email = document.forms['order']['e-mail'].value
    var phone = document.forms['order']['nomor'].value
    var age = document.forms['order']['umur'].value
    var address = document.forms['order']['alamat'].value
    var district = document.forms['order']['al1'].value
    var code = document.forms['order']['kode'].value
    var namecard = document.getElementById('namecard');
    var adrs = document.getElementById('addrs');
    var cvc = document.getElementById('cvc');
    var finalcheck = 0;
    // var error
    var cardnum = document.getElementById('cardnum');
    var en = document.getElementById('errnama')
    var namearea = document.getElementById('name');
    var ep = document.getElementById('errnomor')
    var phonearea = document.getElementById('phone');
    var ee = document.getElementById('erremail')
    var emails = document.getElementById('email');   
    var eg = document.getElementById('errumur')
    var ages = document.getElementById('age');
    var ea1 = document.getElementById('erral1')
    var districts = document.getElementById('district');
    var ea = document.getElementById('erralamat')
    var addressloc = document.getElementById('address');
    var ec = document.getElementById('errkode')
    var postcode = document.getElementById('code');
    var notes = document.getElementById('note');
    var erc = document.getElementById('errcard');
    var ername = document.getElementById('errname');
    var eradd = document.getElementById('erradds');
    var ercvc = document.getElementById('errcvc');
    var 
    i = 0;
    if (name === '') {
        en.innerText = "Name cannot be empty"
        namearea.style.border ="2px solid red";
        i = 1;
        finalcheck = 1;
    } else if (!startWithCapitalLetter(name.charAt(0))) {
        en.innerText = "First letter of the name must be Capital Letter!"
        namearea.style.border ="2px solid red";
        i = 1;
        finalcheck = 1;
    }else if (name.length < 3) {
        en.innerText = "Name must be longer than 2 character!" 
        namearea.style.border ="2px solid red";
        i = 1;
        finalcheck = 1;
    } else if(i == 0)
    {
        namearea.style.border = "2px solid green";
        en.innerText = "";
    }
    i = 0;
    if (phone === '') {
        ep.innerText = "Phone Number cannot be empty"
        phonearea.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }else if (phone.length < 11 ) {
        ep.innerText = "Phone Number must be longer than 11 character!"
        phonearea.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }  else if(!phone.charAt(0) == '+' && !phone.charAt(1) == '6' && !phone.charAt(2) == '2')
    {
        ep.innerText = "Phone Number must start with +62"
        phonearea.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }  else if(i == 0)
    {
        phonearea.style.border = "2px solid green";
        ep.innerText = "";
    }
    i = 0;
    if (email === '') {
        ee.innerText = "Email cannot be empty"
        emails.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }else if (!email.includes('@')) {
        ee.innerText = "Email is Invalid!"
        emails.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }else if (email[0] =='@' ) {
        ee.innerText = "Email is Invalid!"
        emails.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }else if(i == 0){
        emails.style.border="2px solid green";
        ee.innerText = "";
    }
    i = 0;
    if (age === '') {
        eg.innerText = "Age cannot be empty"
        ages.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    } else if(i == 0)
    {
        ages.style.border="2px solid green";
        eg.innerText = "";
    }
    i = 0;
    if (district === '') {
        ea1.innerText = "District cannot be empty"
        districts.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    } else if(i == 0)
    {
        districts.style.border="2px solid green";
        ea1.innerText = "";
    }
    i = 0;
    if (address === '') {
        ea.innerText = "Address must not be empty"
        addressloc.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }else if (address.length < 35 ) {
        ea.innerText = "Address must be more than 35 character! Make sure you have write your district, sub-district, and postal code\n"
        addressloc.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    } else if(i == 0)
    {
        ea.innerText = ""
        addressloc.style.border="2px solid green";
    }
    i = 0;
    if(code === '') {
        ec.innerText = "Postal Code cannot be empty"
        postcode.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }else if (code.length > 5) {
        ec.product = " Postal Code  cannot be longer than 5 character!"
        postcode.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }else if (code.length < 5) {
        ec.product = " Postal Code  cannot be shorter than 5 character!"
        postcode.style.border="2px solid red";
        i = 1;
        finalcheck = 1;
    }else if (i == 0) {
        ec.product = "";
        postcode.style.border="2px solid green";
        ername.innerText="";
    }
    i = 0;
    if(notes.value === '')
    {
        notes.style.border="2px solid red";
        finalcheck = 1;
        i = 1;
    } else if(i == 0){
        notes.style.border="2px solid green";
        ername.innerText="";
    }
    i = 0;
    if(namecard.value === ''){
        namecard.style.border="2px solid red";
        ername.innerText="You need to input Name";
        i = 1;
    } else {
        namecard.style.border="2px solid green";
        ername.innerText="";
    }
    i = 0;
    if(adrs.value === ''){
        adrs.style.border="2px solid red";
        eradd.innerText="You need to input Address";
        i = 1;
    } else {
        adrs.style.border="2px solid green";
        ername.innerText="";
    }
    i = 0;
    if(cvc.value.length < 3){
        cvc.style.border="2px solid red";
        ercvc.innerText="CVC must be 3 digit";
        i = 1;
    } else {
        cvc.style.border="2px solid green";
        ername.innerText="";
    }
    i = 0;
    if(cardcheck == 1){
        if(visacardnumber() == false){
            finalcheck = 1;
            i = 1;  
            cardnum.style.border="2px solid red";
        } else {
            cardnum.style.border="2px solid green";
            ername.innerText="";
        }
        if(i == 1){
            erc.innerText = "Invalid Card Number!";
        }
        i = 0;
    } else if(cardcheck == 2){
        if(mastercardnumber() == false){
            finalcheck = 1;
            i = 1;
            cardnum.style.border="2px solid red";
        } else
        {
            cardnum.style.border="2px solid green";
            ername.innerText="";
        }
        if(i == 1){
            erc.innerText = "Invalid Card Number!";
        }
        i = 0;
    }
    if(finalcheck == 0){
        countprice();  
    } 
}