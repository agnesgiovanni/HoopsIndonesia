var slideIndex = 0;
var idx =0;


var $slider = $('#slider');
var $slideContainer = $slider.find('.slides');
var $slides = $slideContainer.find('.slide');
var dot1 = document.getElementsByClassName("dot1");
var currentslide = 1;

$(function() {
  dot1[currentslide-1].className += " active";
  setInterval(function() {
    for (i = 0; i < dot1.length; i++) {
      dot1[i].className = dot1[i].className.replace(" active", "");
    }
    dot1[currentslide].className += " active";
    $slideContainer.animate({'margin-left':'-=150vw'}, 2000, function(){
      currentslide++;
      if(currentslide === $slides.length)
      {
        currentslide = 1;
        $slideContainer.css('margin-left', 0);
        dot1[currentslide-1].className += " active";
        dot1[$slides.length-1].className = dot1[$slides.length-1].className.replace(" active", "");
      }
    });
  }, 3000);
});
