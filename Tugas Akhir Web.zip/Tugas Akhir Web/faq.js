var acc = document.getElementsByClassName("pertanyaan")
var i

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function() {
        this.classList.toggle("active")

        var panel = this.nextElementSibling
        if (panel.style.maxHeight) {
            panel.style.maxHeight = null
        } else {
            panel.style.maxHeight = panel.scrollHeight + "px"
        }
    })
}

function startWithCapitalLetter(word){
    return word.charCodeAt(0)>=65 && word.charCodeAt(0)<=90;
}

function checkVali(){
    var i = 0
    var name = document.forms['order']['nama'].value
    var email = document.forms['order']['e-mail'].value


    // var error
    var en = document.getElementById('errnama')
    var ee = document.getElementById('erremail')

    if (name === "") {
        en.innerText = "Name cannot be empty"
    } else if (!startWithCapitalLetter(name.charAt(0))) {
        en.innerText = "First letter of the name must be Capital Letter!"
    }else if (name.length < 3) {
        en.innerText = "Name must be longer than 2 character!" 
    }else if(i == 0){
        emails.style.border="2px solid green";
        ee.innerText = ""
    }

    if (email === "") {
        ee.innerText = "Email cannot be empty"
    }else if (!email.includes('@')) {
        ee.innerText = "Email is Invalid!"
    }else if (email[0] =='@' ) {
        ee.innerText = "Email is Invalid!"
        emails.style.border="2px solid red";
        i = 1;
    }else if(i == 0){
        emails.style.border="2px solid green";
        ee.innerText = ""
    }else {
        i++
        alert('Request Submitted!')
    }
}