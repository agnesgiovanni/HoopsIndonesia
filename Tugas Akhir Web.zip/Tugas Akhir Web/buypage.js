function hover1(element) {
  element.setAttribute('src', 'assets/shoeshover1.jpg');
}
function unhover1(element) {
  element.setAttribute('src', 'assets/shoes1.jpg');
}
function hover2(element) {
  element.setAttribute('src', 'assets/shoeshover2.jpg');
}
function unhover2(element) {
  element.setAttribute('src', 'assets/shoes2.jpg');
}
function hover3(element) {
  element.setAttribute('src', 'assets/shoeshover3.jpg');
}
function unhover3(element) {
  element.setAttribute('src', 'assets/shoes3.jpg');
}
function hover4(element) {
  element.setAttribute('src', 'assets/shoeshover4.jpg');
}
function unhover4(element) {
  element.setAttribute('src', 'assets/shoes4.jpg');
}
function hover5(element) {
  element.setAttribute('src', 'assets/shoeshover5.jpg');
}
function unhover5(element) {
  element.setAttribute('src', 'assets/shoes5.jpg');
}
function hover6(element) {
  element.setAttribute('src', 'assets/shoeshover6.jpg');
}
function unhover6(element) {
  element.setAttribute('src', 'assets/shoes6.jpg');
}
function hover7(element) {
  element.setAttribute('src', 'assets/shoeshover7.jpg');
}
function unhover7(element) {
  element.setAttribute('src', 'assets/shoes7.jpg');
}
function hover8(element) {
  element.setAttribute('src', 'assets/shoeshover8.jpg');
}
function unhover8(element) {
  element.setAttribute('src', 'assets/shoes8.jpg');
}
function hover9(element) {
  element.setAttribute('src', 'assets/shoeshover9.jpg');
}
function unhover9(element) {
  element.setAttribute('src', 'assets/shoes9.jpg');
}
function hover10(element) {
  element.setAttribute('src', 'assets/shoeshover10.jpg');
}
function unhover10(element) {
  element.setAttribute('src', 'assets/shoes10.jpg');
}
function hover11(element) {
  element.setAttribute('src', 'assets/shoeshover11.jpg');
}
function unhover11(element) {
  element.setAttribute('src', 'assets/shoes11.jpg');
}
function hover12(element) {
  element.setAttribute('src', 'assets/shoeshover12.jpg');
}
function unhover12(element) {
  element.setAttribute('src', 'assets/shoes12.jpg');
}